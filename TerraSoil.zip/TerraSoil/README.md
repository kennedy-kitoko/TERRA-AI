# 🌱 TerraSoil Library

Bibliothèque Arduino pour capteur **NPK Soil Sensor RS485** (SN-300*-TR-*-N01)

![Version](https://img.shields.io/badge/version-1.0.0-green)
![License](https://img.shields.io/badge/license-MIT-blue)
![Arduino](https://img.shields.io/badge/Arduino-Compatible-brightgreen)

## 📋 Description

TerraSoil est une bibliothèque simple et efficace pour lire les **10 paramètres** du capteur de sol NPK via RS485 Modbus RTU :

- 💧 **Humidité** (%)
- 🌡️ **Température** (°C)
- ⚡ **Conductivité électrique** (µS/cm)
- 🧪 **pH**
- 🔴 **Azote N** (mg/kg)
- 🟠 **Phosphore P** (mg/kg)
- 🟡 **Potassium K** (mg/kg)
- 🧂 **Salinité**
- 💎 **TDS** - Total Dissolved Solids (mg/L)
- 🌾 **Fertilité** (mg/kg)

## ✨ Caractéristiques

- ✅ **Simple** : Une seule fonction pour tout lire
- ✅ **Complet** : Lecture des 10 paramètres
- ✅ **Flexible** : Configuration personnalisable
- ✅ **Fiable** : Gestion CRC et timeout
- ✅ **Compatible** : ESP32, ESP8266, Arduino

## 🔧 Installation

### Via Arduino IDE

1. Télécharger le fichier `TerraSoil.zip`
2. Dans Arduino IDE : **Sketch** → **Include Library** → **Add .ZIP Library**
3. Sélectionner le fichier téléchargé

### Manuelle

1. Copier le dossier `TerraSoil` dans :
   - Windows : `Documents/Arduino/libraries/`
   - Mac : `~/Documents/Arduino/libraries/`
   - Linux : `~/Arduino/libraries/`

## 🚀 Utilisation rapide

```cpp
#include <TerraSoil.h>

#define RS485_RX_PIN   44  // GPIO44 (D7 sur XIAO)
#define RS485_TX_PIN   43  // GPIO43 (D6 sur XIAO)
#define RS485_RTS_PIN  1   // GPIO1  (D1 sur XIAO)

HardwareSerial RS485Serial(1);
TerraSoil sensor(&RS485Serial, RS485_RTS_PIN);
TerraSoilData data;

void setup() {
  Serial.begin(115200);
  sensor.begin(RS485_RX_PIN, RS485_TX_PIN, 4800);
}

void loop() {
  // LECTURE COMPLÈTE EN UNE FONCTION !
  if (sensor.readSensor(data)) {
    Serial.printf("Humidité: %.1f%%\n", data.moisture);
    Serial.printf("Température: %.1f°C\n", data.temperature);
    Serial.printf("pH: %.1f\n", data.ph);
    Serial.printf("N: %d mg/kg\n", data.nitrogen);
    Serial.printf("P: %d mg/kg\n", data.phosphorus);
    Serial.printf("K: %d mg/kg\n", data.potassium);
  }
  
  delay(5000);
}
```

## 📊 Structure des données

```cpp
struct TerraSoilData {
  float moisture;        // Humidité (%)
  float temperature;     // Température (°C)
  uint16_t conductivity; // Conductivité (µS/cm)
  float ph;              // pH
  uint16_t nitrogen;     // Azote N (mg/kg)
  uint16_t phosphorus;   // Phosphore P (mg/kg)
  uint16_t potassium;    // Potassium K (mg/kg)
  uint16_t salinity;     // Salinité
  uint16_t tds;          // TDS (mg/L)
  uint16_t fertility;    // Fertilité (mg/kg)
  bool success;          // true si succès
  uint32_t timestamp;    // Timestamp
};
```

## 🔌 Câblage pour XIAO ESP32-S3

```
[Batterie 5V]
  │
  ├─► +5V ──┬─► XIAO (5V)
  │         ├─► RS485 (VCC)
  │         └─► Capteur (Marron)
  │
  └─► GND ──┬─► XIAO (GND)
            ├─► RS485 (GND)
            └─► Capteur (Noir)

[Capteur NPK]
  🟡 Jaune  → RS485 A
  🔵 Bleu   → RS485 B

[RS485 Module]
  RO (RX)   → XIAO GPIO44 (D7)
  DI (TX)   → XIAO GPIO43 (D6)
  DE + RE   → XIAO GPIO1  (D1)  [reliés ensemble]
```

## 📖 API Reference

### Constructeur

```cpp
TerraSoil(HardwareSerial* serial, uint8_t rtsPin, uint8_t address = 0x01)
```

### Méthodes principales

#### `begin()`
```cpp
bool begin(uint8_t rxPin, uint8_t txPin, uint32_t baud = 4800)
```
Initialise la communication RS485.

#### `readSensor()` ⭐ **FONCTION PRINCIPALE**
```cpp
bool readSensor(TerraSoilData &data)
```
Lit tous les paramètres du capteur.
- **Retour** : `true` si succès
- **Paramètre** : référence vers `TerraSoilData`

#### `readRegister()`
```cpp
bool readRegister(uint16_t regAddress, uint16_t &value)
```
Lit un registre spécifique.

### Configuration

```cpp
void setReadDelay(uint16_t delayMs);  // Délai entre lectures (défaut: 50ms)
void setTimeout(uint16_t timeoutMs);   // Timeout (défaut: 300ms)
uint8_t getAddress() const;            // Obtenir l'adresse Modbus
static const char* getVersion();       // Version de la lib
```

## 📝 Exemples

La bibliothèque inclut deux exemples :

1. **BasicReading** : Sortie JSON compacte
2. **AdvancedReading** : Affichage formaté détaillé

Accès : **File** → **Examples** → **TerraSoil**

## 🔍 Dépannage

| Problème | Solution |
|----------|----------|
| Pas de données | Vérifier connexions A/B |
| Timeout | Vérifier DE/RE reliés ensemble |
| Valeurs 0 | Vérifier alimentation 5V |
| CRC Error | Vérifier câblage et masse commune |

## 📋 Registres Modbus

| Registre | Adresse | Description | Unité |
|----------|---------|-------------|-------|
| Humidité | 0x0000 | Humidité du sol | % |
| Température | 0x0001 | Température | °C |
| Conductivité | 0x0002 | EC | µS/cm |
| pH | 0x0003 | pH du sol | pH |
| Azote | 0x0004 | N | mg/kg |
| Phosphore | 0x0005 | P | mg/kg |
| Potassium | 0x0006 | K | mg/kg |
| Salinité | 0x0007 | Salinité | - |
| TDS | 0x0008 | Solides dissous | mg/L |
| Fertilité | 0x000C | Fertilité | mg/kg |

## 🛠️ Compatibilité

- ✅ ESP32 / ESP32-S3 / ESP32-C3
- ✅ ESP8266
- ✅ Arduino Mega
- ✅ Arduino Due
- ✅ SAMD (MKR, Zero)

## 📄 Licence

MIT License - Utilisation libre

## 👥 Auteurs

**TerraSoil Team** - 2025
*author: KITOKO MUYUNGA KENNEDY
* https://github.com/kennedy-kitoko/TERRA-AI

## 🌟 Contribuer

Les contributions sont les bienvenues ! N'hésitez pas à ouvrir une issue ou pull request.

---

**🌱 Cultivez avec précision ! 🌱**
